CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR UNIQUE NOT NULL,
    hashed_password VARCHAR NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS market_data (
    id SERIAL PRIMARY KEY,
    symbol VARCHAR DEFAULT 'XAUUSD',
    timeframe VARCHAR NOT NULL,
    timestamp TIMESTAMPTZ NOT NULL,
    open DOUBLE PRECISION,
    high DOUBLE PRECISION,
    low DOUBLE PRECISION,
    close DOUBLE PRECISION,
    volume DOUBLE PRECISION,
    bid DOUBLE PRECISION,
    ask DOUBLE PRECISION,
    spread DOUBLE PRECISION,
    source VARCHAR,
    UNIQUE(symbol, timeframe, timestamp, source)
);
CREATE INDEX IF NOT EXISTS idx_market_data_symbol_tf_ts ON market_data (symbol, timeframe, timestamp);

CREATE TABLE IF NOT EXISTS signals (
    id SERIAL PRIMARY KEY,
    symbol VARCHAR DEFAULT 'XAUUSD',
    created_at TIMESTAMPTZ DEFAULT now(),
    signal VARCHAR NOT NULL,
    score DOUBLE PRECISION,
    entry_low DOUBLE PRECISION,
    entry_high DOUBLE PRECISION,
    stop_loss DOUBLE PRECISION,
    take_profit_1 DOUBLE PRECISION,
    take_profit_2 DOUBLE PRECISION,
    take_profit_3 DOUBLE PRECISION,
    risk_reward DOUBLE PRECISION,
    trend VARCHAR,
    market_structure VARCHAR,
    momentum VARCHAR,
    news_risk VARCHAR,
    reasons JSONB,
    features_used JSONB,
    model_version VARCHAR,
    market_price_at_signal DOUBLE PRECISION
);

CREATE TABLE IF NOT EXISTS signal_results (
    id SERIAL PRIMARY KEY,
    signal_id INTEGER REFERENCES signals(id),
    outcome VARCHAR,
    closed_price DOUBLE PRECISION,
    closed_at TIMESTAMPTZ,
    pnl_r DOUBLE PRECISION
);

CREATE TABLE IF NOT EXISTS news (
    id SERIAL PRIMARY KEY,
    event VARCHAR NOT NULL,
    scheduled_time TIMESTAMPTZ NOT NULL,
    impact VARCHAR,
    expected VARCHAR,
    previous VARCHAR,
    actual VARCHAR,
    source VARCHAR
);
CREATE INDEX IF NOT EXISTS idx_news_scheduled_time ON news (scheduled_time);

CREATE TABLE IF NOT EXISTS support_resistance (
    id SERIAL PRIMARY KEY,
    symbol VARCHAR DEFAULT 'XAUUSD',
    level_type VARCHAR NOT NULL,
    price DOUBLE PRECISION NOT NULL,
    strength VARCHAR,
    basis VARCHAR,
    timeframe VARCHAR,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS backtests (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT now(),
    params JSONB,
    starting_balance DOUBLE PRECISION,
    ending_balance DOUBLE PRECISION,
    win_rate DOUBLE PRECISION,
    trades INTEGER,
    max_drawdown DOUBLE PRECISION,
    profit_factor DOUBLE PRECISION,
    sharpe_ratio DOUBLE PRECISION,
    longest_losing_streak INTEGER,
    equity_curve JSONB
);

CREATE TABLE IF NOT EXISTS user_alerts (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    alert_type VARCHAR NOT NULL,
    config JSONB,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS model_versions (
    id SERIAL PRIMARY KEY,
    version VARCHAR UNIQUE NOT NULL,
    trained_at TIMESTAMPTZ,
    metrics JSONB,
    notes TEXT,
    is_active BOOLEAN DEFAULT false
);
