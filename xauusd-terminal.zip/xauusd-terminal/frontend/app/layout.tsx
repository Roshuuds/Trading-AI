import "./globals.css";

export const metadata = {
  title: "XAUUSD AI Market Intelligence Terminal",
  description: "Probability-based XAUUSD analysis and signals — educational use only.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-terminal-bg text-terminal-text min-h-screen">
        {children}
      </body>
    </html>
  );
}
