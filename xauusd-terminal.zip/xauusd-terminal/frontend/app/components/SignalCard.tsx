"use client";
import { SignalData } from "@/lib/api";

const colorFor = (signal: string) =>
  signal === "BUY" ? "text-terminal-buy border-terminal-buy" :
  signal === "SELL" ? "text-terminal-sell border-terminal-sell" :
  "text-terminal-wait border-terminal-wait";

export default function SignalCard({ data }: { data: SignalData | null }) {
  if (!data) {
    return (
      <div className="bg-terminal-panel border border-terminal-border rounded-lg p-6">
        <p className="text-terminal-muted">Loading signal…</p>
      </div>
    );
  }

  const noData = data.reasons.some(r => r.toLowerCase().includes("unavailable") || r.toLowerCase().includes("insufficient"));

  return (
    <div className={`bg-terminal-panel border rounded-lg p-6 ${colorFor(data.signal)}`}>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-sm uppercase tracking-wide text-terminal-muted">AI Signal</h2>
        <span className="text-xs text-terminal-muted">{data.data_timestamp ?? "—"}</span>
      </div>

      <div className="text-4xl font-bold mb-1">{data.signal}</div>
      <div className="text-terminal-muted mb-4">Signal Confidence: {data.score}/100</div>

      {noData ? (
        <p className="text-terminal-wait text-sm">⚠ {data.reasons[0]}</p>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 text-sm mb-4">
            <div>
              <div className="text-terminal-muted">Entry Zone</div>
              <div>{data.entry_zone.low ?? "—"} – {data.entry_zone.high ?? "—"}</div>
            </div>
            <div>
              <div className="text-terminal-muted">Stop Loss</div>
              <div>{data.stop_loss ?? "—"}</div>
            </div>
            {data.take_profit.map((tp, i) => (
              <div key={i}>
                <div className="text-terminal-muted">Take Profit {i + 1}</div>
                <div>{tp}</div>
              </div>
            ))}
            <div>
              <div className="text-terminal-muted">Risk/Reward</div>
              <div>{data.risk_reward ? `1:${data.risk_reward}` : "—"}</div>
            </div>
            <div>
              <div className="text-terminal-muted">News Risk</div>
              <div>{data.news_risk}</div>
            </div>
          </div>
          <div className="text-sm">
            <div className="text-terminal-muted mb-1">Reasons</div>
            <ul className="list-disc list-inside space-y-1">
              {data.reasons.map((r, i) => <li key={i}>{r}</li>)}
            </ul>
          </div>
        </>
      )}

      <p className="text-xs text-terminal-muted mt-4 border-t border-terminal-border pt-3">
        {data.disclaimer}
      </p>
    </div>
  );
}
