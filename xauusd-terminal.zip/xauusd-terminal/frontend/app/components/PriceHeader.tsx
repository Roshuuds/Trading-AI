"use client";
import { PriceData } from "@/lib/api";

export default function PriceHeader({ data }: { data: PriceData | null }) {
  if (!data) {
    return <div className="text-terminal-muted">Loading price…</div>;
  }

  if (data.data_status === "unavailable") {
    return (
      <div className="bg-terminal-panel border border-terminal-wait rounded-lg p-4 text-terminal-wait">
        ⚠ {data.message ?? "Live market data unavailable."}
      </div>
    );
  }

  return (
    <div className="flex flex-wrap items-center gap-6 bg-terminal-panel border border-terminal-border rounded-lg p-4">
      <div>
        <div className="text-terminal-muted text-xs">XAUUSD</div>
        <div className="text-3xl font-bold">${data.price?.toFixed(2)}</div>
      </div>
      <div>
        <div className="text-terminal-muted text-xs">Bid / Ask</div>
        <div>{data.bid?.toFixed(2)} / {data.ask?.toFixed(2)}</div>
      </div>
      <div>
        <div className="text-terminal-muted text-xs">Spread</div>
        <div>{data.spread?.toFixed(2)}</div>
      </div>
      <div>
        <div className="text-terminal-muted text-xs">Session</div>
        <div>{data.session}</div>
      </div>
      <div>
        <div className="text-terminal-muted text-xs">Market</div>
        <div>{data.market_status}</div>
      </div>
      {data.data_status === "delayed" && (
        <div className="text-terminal-wait text-sm">⚠ DATA DELAYED</div>
      )}
    </div>
  );
}
