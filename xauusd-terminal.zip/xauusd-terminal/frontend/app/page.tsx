"use client";
import { useEffect, useState } from "react";
import { getPrice, getSignal, PriceData, SignalData } from "@/lib/api";
import PriceHeader from "./components/PriceHeader";
import SignalCard from "./components/SignalCard";

export default function Dashboard() {
  const [price, setPrice] = useState<PriceData | null>(null);
  const [signal, setSignal] = useState<SignalData | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        const [p, s] = await Promise.all([getPrice(), getSignal()]);
        setPrice(p);
        setSignal(s);
        setError(null);
      } catch (e) {
        setError("Could not reach the backend API. Is it running?");
      }
    };
    load();
    const interval = setInterval(load, 15000); // poll every 15s
    return () => clearInterval(interval);
  }, []);

  return (
    <main className="max-w-5xl mx-auto p-6 space-y-6">
      <header className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">XAUUSD AI Market Intelligence Terminal</h1>
      </header>

      {error && (
        <div className="bg-terminal-panel border border-terminal-sell text-terminal-sell rounded-lg p-4">
          {error}
        </div>
      )}

      <PriceHeader data={price} />
      <SignalCard data={signal} />

      <footer className="text-xs text-terminal-muted border-t border-terminal-border pt-4">
        This platform provides market analysis and probability-based signals for
        educational and informational purposes only. It does not guarantee profits
        or predict future prices with certainty. Trading XAUUSD involves substantial
        risk, including the possibility of losing your entire trading capital. Always
        verify market conditions and use appropriate risk management.
      </footer>
    </main>
  );
}
