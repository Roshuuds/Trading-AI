/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        terminal: {
          bg: "#0b0e14",
          panel: "#121722",
          border: "#1f2733",
          text: "#e6e9ef",
          muted: "#8892a4",
          buy: "#16c784",
          sell: "#ea3943",
          wait: "#f0b90b",
        },
      },
    },
  },
  plugins: [],
};
