const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";

export type PriceData = {
  symbol: string;
  price: number | null;
  bid: number | null;
  ask: number | null;
  spread: number | null;
  market_status: string;
  session: string | null;
  data_status: "live" | "unavailable" | "delayed";
  message?: string | null;
};

export type SignalData = {
  symbol: string;
  signal: "BUY" | "SELL" | "WAIT";
  score: number;
  entry_zone: { low: number | null; high: number | null };
  stop_loss: number | null;
  take_profit: number[];
  risk_reward: number | null;
  trend: string | null;
  market_structure: string | null;
  momentum: string | null;
  news_risk: string;
  reasons: string[];
  data_timestamp: string | null;
  disclaimer: string;
};

async function fetchJSON<T>(path: string): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, { cache: "no-store" });
  if (!res.ok) throw new Error(`Request failed: ${res.status}`);
  return res.json();
}

export const getPrice = () => fetchJSON<PriceData>("/api/xauusd/price");
export const getSignal = () => fetchJSON<SignalData>("/api/xauusd/signal");
