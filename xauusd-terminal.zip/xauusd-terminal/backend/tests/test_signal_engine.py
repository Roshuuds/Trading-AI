import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.services.signal_engine import generate_signal, SignalInputs, TimeframeView


def bullish_inputs(**overrides):
    base = dict(
        price=2400, ema_20=2395, ema_50=2380, ema_200=2350,
        rsi_14=62, macd_hist=1.2, adx_14=30, atr_14=8,
        market_structure="BULLISH STRUCTURE",
        nearest_support=2390, nearest_resistance=2430,
        timeframes=[
            TimeframeView("15m", "Bullish", "Strong"),
            TimeframeView("1h", "Bullish", "Strong"),
            TimeframeView("4h", "Bullish", "Medium"),
        ],
        spread=0.3, typical_spread=0.3,
        news_high_impact_within_window=False,
        dxy_bias="Bearish", yield_trend="Falling",
    )
    base.update(overrides)
    return SignalInputs(**base)


def test_strong_bullish_setup_produces_buy():
    result = generate_signal(bullish_inputs())
    assert result.signal == "BUY"
    assert result.score > 0


def test_wide_spread_forces_wait():
    result = generate_signal(bullish_inputs(spread=2.0, typical_spread=0.3))
    assert result.signal == "WAIT"


def test_conflicting_timeframes_lower_confidence():
    mixed = bullish_inputs(timeframes=[
        TimeframeView("15m", "Bullish", "Strong"),
        TimeframeView("1h", "Bearish", "Medium"),
        TimeframeView("4h", "Neutral", "Weak"),
    ])
    result = generate_signal(mixed)
    assert "disagree" in " ".join(result.reasons).lower() or result.signal == "WAIT"


def test_bearish_setup_produces_sell():
    bearish = bullish_inputs(
        price=2400, ema_20=2405, ema_50=2420, ema_200=2440,
        rsi_14=35, macd_hist=-1.0, market_structure="BEARISH STRUCTURE",
        timeframes=[
            TimeframeView("15m", "Bearish", "Strong"),
            TimeframeView("1h", "Bearish", "Strong"),
            TimeframeView("4h", "Bearish", "Medium"),
        ],
        dxy_bias="Bullish", yield_trend="Rising",
    )
    result = generate_signal(bearish)
    assert result.signal == "SELL"
