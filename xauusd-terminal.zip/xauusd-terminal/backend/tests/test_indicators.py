import pandas as pd
import numpy as np
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.services.indicators import rsi, ema, macd, atr, compute_all_indicators


def make_df(n=300, seed=1):
    rng = np.random.default_rng(seed)
    price = 2000 + np.cumsum(rng.normal(0, 2, n))
    df = pd.DataFrame({
        "open": price + rng.normal(0, 0.5, n),
        "high": price + abs(rng.normal(1, 0.5, n)),
        "low": price - abs(rng.normal(1, 0.5, n)),
        "close": price,
        "volume": rng.integers(100, 1000, n),
    }, index=pd.date_range("2024-01-01", periods=n, freq="h"))
    return df


def test_rsi_bounds():
    df = make_df()
    r = rsi(df["close"])
    assert (r >= 0).all() and (r <= 100).all()


def test_ema_no_lookahead():
    df = make_df()
    e = ema(df["close"], 20)
    # EMA value at i must not change if future rows are dropped
    truncated = ema(df["close"].iloc[:100], 20)
    assert np.isclose(e.iloc[99], truncated.iloc[99])


def test_macd_shapes():
    df = make_df()
    line, signal, hist = macd(df["close"])
    assert len(line) == len(df) == len(signal) == len(hist)


def test_atr_positive():
    df = make_df()
    a = atr(df)
    assert (a.dropna() >= 0).all()


def test_compute_all_indicators_columns():
    df = make_df()
    out = compute_all_indicators(df)
    for col in ["ema_9", "ema_200", "rsi_14", "macd", "atr_14", "bb_upper", "adx_14"]:
        assert col in out.columns
