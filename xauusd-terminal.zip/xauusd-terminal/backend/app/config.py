"""
Central configuration. All secrets / provider endpoints come from environment
variables so the app can be pointed at any real XAUUSD data provider without
code changes (per requirement: modular architecture, no hard-coded prices).
"""
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # --- Core ---
    APP_NAME: str = "XAUUSD AI Market Intelligence Terminal"
    ENV: str = "development"
    SECRET_KEY: str = "CHANGE_ME_IN_PRODUCTION"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 12

    # --- Database ---
    DATABASE_URL: str = "postgresql://xauuser:xaupass@localhost:5432/xauusd"

    # --- Cache ---
    REDIS_URL: str = "redis://localhost:6379/0"

    # --- Market data provider (plug in a real one: OANDA, Polygon, Twelve Data,
    # a broker's FIX/REST bridge, etc.) Leave blank to force
    # "Live market data unavailable" behavior rather than fabricating prices. ---
    MARKET_DATA_PROVIDER: str = ""          # e.g. "oanda", "twelvedata", "polygon"
    MARKET_DATA_API_KEY: str = ""
    MARKET_DATA_BASE_URL: str = ""

    # --- News / macro calendar provider ---
    NEWS_PROVIDER: str = ""                 # e.g. "forexfactory", "tradingeconomics"
    NEWS_API_KEY: str = ""

    # --- Broker contract spec (never assume a fixed lot size) ---
    DEFAULT_CONTRACT_SIZE_OZ: Optional[float] = None  # must come from connected broker

    # --- News risk window ---
    NEWS_RISK_WINDOW_MINUTES: int = 30

    # --- Model confidence floor below which the engine forces WAIT ---
    MIN_MODEL_CONFIDENCE: float = 55.0

    class Config:
        env_file = ".env"


settings = Settings()
