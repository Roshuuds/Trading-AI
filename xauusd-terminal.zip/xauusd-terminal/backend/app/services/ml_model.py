"""
Optional ML layer: classifies next-N-bar move as UP / DOWN / NO_SIGNIFICANT_MOVE.
Chronological walk-forward validation only — never random train/test split on
time series (prevents lookahead / leakage / survivorship bias per spec).
"""
import pandas as pd
import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
)
from xgboost import XGBClassifier

FEATURE_COLUMNS = [
    "rsi_14", "macd_hist", "adx_14", "atr_14",
    "ema_20", "ema_50", "ema_200",
    "bb_upper", "bb_mid", "bb_lower",
]


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    feats = df.copy()
    feats["ema20_dist"] = (feats["close"] - feats["ema_20"]) / feats["close"]
    feats["ema50_dist"] = (feats["close"] - feats["ema_50"]) / feats["close"]
    feats["bb_position"] = (feats["close"] - feats["bb_lower"]) / (feats["bb_upper"] - feats["bb_lower"])
    feats["returns_1"] = feats["close"].pct_change(1)
    feats["returns_5"] = feats["close"].pct_change(5)
    return feats


def build_labels(df: pd.DataFrame, horizon: int = 5, move_threshold: float = 0.0015) -> pd.Series:
    """Label each bar using ONLY future data (fine for labels, never for features)."""
    future_return = df["close"].shift(-horizon) / df["close"] - 1
    labels = pd.Series("NO_SIGNIFICANT_MOVE", index=df.index)
    labels[future_return > move_threshold] = "UP"
    labels[future_return < -move_threshold] = "DOWN"
    return labels


def walk_forward_splits(n: int, n_splits: int = 5, min_train_size: int = 500):
    """Yield chronological (train_idx, test_idx) pairs — expanding window."""
    fold_size = (n - min_train_size) // n_splits
    for i in range(n_splits):
        train_end = min_train_size + i * fold_size
        test_end = train_end + fold_size
        if test_end > n:
            break
        yield list(range(0, train_end)), list(range(train_end, test_end))


def train_and_validate(df: pd.DataFrame, horizon: int = 5) -> dict:
    feats = build_features(df).dropna()
    labels = build_labels(feats, horizon=horizon).loc[feats.index]

    all_cols = FEATURE_COLUMNS + ["ema20_dist", "ema50_dist", "bb_position", "returns_1", "returns_5"]
    X = feats[all_cols]
    y = labels.map({"DOWN": 0, "NO_SIGNIFICANT_MOVE": 1, "UP": 2})

    fold_metrics = []
    for train_idx, test_idx in walk_forward_splits(len(X)):
        X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

        model = XGBClassifier(
            n_estimators=200, max_depth=4, learning_rate=0.05,
            objective="multi:softprob", num_class=3, eval_metric="mlogloss",
        )
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        probs = model.predict_proba(X_test)

        fold_metrics.append({
            "accuracy": accuracy_score(y_test, preds),
            "precision_macro": precision_score(y_test, preds, average="macro", zero_division=0),
            "recall_macro": recall_score(y_test, preds, average="macro", zero_division=0),
            "f1_macro": f1_score(y_test, preds, average="macro", zero_division=0),
            "roc_auc_ovr": roc_auc_score(y_test, probs, multi_class="ovr") if len(set(y_test)) > 1 else None,
        })

    avg_metrics = {
        k: float(np.mean([m[k] for m in fold_metrics if m[k] is not None]))
        for k in fold_metrics[0]
    }
    return {"fold_metrics": fold_metrics, "average_metrics": avg_metrics}
