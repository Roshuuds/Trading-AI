"""
Swing detection and BOS/CHoCH classification using a simple fractal method
(a swing high/low is confirmed once `lookback` bars on each side are lower/higher).
"""
import pandas as pd


def find_swings(df: pd.DataFrame, lookback: int = 3):
    highs, lows = df["high"], df["low"]
    swing_highs, swing_lows = [], []
    for i in range(lookback, len(df) - lookback):
        window_high = highs.iloc[i - lookback:i + lookback + 1]
        window_low = lows.iloc[i - lookback:i + lookback + 1]
        if highs.iloc[i] == window_high.max():
            swing_highs.append((df.index[i], highs.iloc[i]))
        if lows.iloc[i] == window_low.min():
            swing_lows.append((df.index[i], lows.iloc[i]))
    return swing_highs, swing_lows


def classify_structure(swing_highs, swing_lows):
    """Compare the last two confirmed swing highs and lows to label structure."""
    labels = []
    if len(swing_highs) >= 2:
        labels.append("HH" if swing_highs[-1][1] > swing_highs[-2][1] else "LH")
    if len(swing_lows) >= 2:
        labels.append("HL" if swing_lows[-1][1] > swing_lows[-2][1] else "LL")

    if "HH" in labels and "HL" in labels:
        structure = "BULLISH STRUCTURE"
    elif "LH" in labels and "LL" in labels:
        structure = "BEARISH STRUCTURE"
    else:
        structure = "RANGE"

    return structure, labels


def detect_bos_choch(df: pd.DataFrame, swing_highs, swing_lows):
    """
    BOS: price closes beyond the most recent swing high/low in the direction
    of the prevailing structure (continuation).
    CHoCH: price closes beyond a swing point AGAINST the prevailing structure
    (early reversal signal).
    Returns the most recent event, or None.
    """
    if not swing_highs or not swing_lows:
        return None

    structure, _ = classify_structure(swing_highs, swing_lows)
    last_close = df["close"].iloc[-1]
    last_swing_high = swing_highs[-1][1]
    last_swing_low = swing_lows[-1][1]

    if structure == "BULLISH STRUCTURE":
        if last_close > last_swing_high:
            return {"event": "BOS", "direction": "bullish", "level": last_swing_high}
        if last_close < last_swing_low:
            return {"event": "CHoCH", "direction": "bearish", "level": last_swing_low}
    elif structure == "BEARISH STRUCTURE":
        if last_close < last_swing_low:
            return {"event": "BOS", "direction": "bearish", "level": last_swing_low}
        if last_close > last_swing_high:
            return {"event": "CHoCH", "direction": "bullish", "level": last_swing_high}
    return None


def analyze_market_structure(df: pd.DataFrame, lookback: int = 3) -> dict:
    swing_highs, swing_lows = find_swings(df, lookback)
    structure, labels = classify_structure(swing_highs, swing_lows)
    event = detect_bos_choch(df, swing_highs, swing_lows)
    return {
        "structure": structure,
        "labels": labels,
        "last_swing_high": swing_highs[-1] if swing_highs else None,
        "last_swing_low": swing_lows[-1] if swing_lows else None,
        "structure_event": event,
    }
