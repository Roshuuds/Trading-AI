"""
Rules-based weighted scoring engine (Section 15/16 of spec).
This produces a "Signal Confidence" score, explicitly NOT a calibrated
win-probability, unless a statistically validated model (see ml_model.py)
has been trained and its calibration metrics stored in model_versions.
"""
from dataclasses import dataclass, field
from typing import Optional

WEIGHTS = {
    "technical_trend": 20,
    "market_structure": 15,
    "momentum": 15,
    "support_resistance": 10,
    "volatility": 10,
    "multi_timeframe": 15,
    "macro_news": 10,
    "liquidity_price_action": 5,
}


@dataclass
class TimeframeView:
    timeframe: str
    trend: str          # Strong Bullish / Bullish / Neutral / Bearish / Strong Bearish
    momentum: str        # Strong / Medium / Weak
    signal: str = "WAIT"


@dataclass
class SignalInputs:
    price: float
    ema_20: float
    ema_50: float
    ema_200: float
    rsi_14: float
    macd_hist: float
    adx_14: float
    atr_14: float
    market_structure: str            # BULLISH STRUCTURE / BEARISH STRUCTURE / RANGE
    nearest_support: Optional[float]
    nearest_resistance: Optional[float]
    timeframes: list[TimeframeView]
    spread: float
    typical_spread: float
    news_high_impact_within_window: bool
    dxy_bias: str = "Neutral"        # Bullish / Bearish / Neutral
    yield_trend: str = "Neutral"     # Rising / Falling / Neutral
    equal_highs_nearby: bool = False
    equal_lows_nearby: bool = False


@dataclass
class SignalOutput:
    signal: str
    score: float
    bullish_score: float
    bearish_score: float
    reasons: list[str] = field(default_factory=list)
    news_risk: str = "Low"


def _trend_score(inp: SignalInputs):
    """EMA stack + ADX trend strength -> bullish/bearish contribution (0-1 each direction)."""
    bullish = 0.0
    bearish = 0.0
    if inp.price > inp.ema_50:
        bullish += 0.5
    else:
        bearish += 0.5
    if inp.ema_20 > inp.ema_50:
        bullish += 0.3
    else:
        bearish += 0.3
    if inp.ema_50 > inp.ema_200:
        bullish += 0.2
    else:
        bearish += 0.2
    # ADX scales conviction (weak trend => pull both toward neutral)
    strength = min(inp.adx_14 / 40, 1.0)
    return bullish * strength, bearish * strength


def _structure_score(inp: SignalInputs):
    if inp.market_structure == "BULLISH STRUCTURE":
        return 1.0, 0.0
    if inp.market_structure == "BEARISH STRUCTURE":
        return 0.0, 1.0
    return 0.3, 0.3  # range = weak/ambiguous both ways


def _momentum_score(inp: SignalInputs):
    bullish = bearish = 0.0
    if inp.rsi_14 > 55:
        bullish += 0.5
    elif inp.rsi_14 < 45:
        bearish += 0.5
    else:
        bullish += 0.1
        bearish += 0.1
    if inp.macd_hist > 0:
        bullish += 0.5
    else:
        bearish += 0.5
    return bullish, bearish


def _sr_score(inp: SignalInputs):
    """Reward price being near support (buy zone) or resistance (sell zone)."""
    if inp.nearest_support is None or inp.nearest_resistance is None:
        return 0.2, 0.2
    dist_to_support = abs(inp.price - inp.nearest_support)
    dist_to_resistance = abs(inp.nearest_resistance - inp.price)
    total = dist_to_support + dist_to_resistance
    if total == 0:
        return 0.5, 0.5
    bullish = 1 - (dist_to_support / total)  # closer to support => more bullish
    bearish = 1 - (dist_to_resistance / total)
    return bullish, bearish


def _volatility_score(inp: SignalInputs):
    """High spread relative to typical, or extreme ATR, reduces confidence both ways."""
    if inp.typical_spread and inp.spread > inp.typical_spread * 2:
        return 0.1, 0.1  # unusually high spread -> low confidence in either direction
    return 0.6, 0.6


def _mtf_score(inp: SignalInputs):
    bullish_votes = sum(1 for tf in inp.timeframes if "Bullish" in tf.trend)
    bearish_votes = sum(1 for tf in inp.timeframes if "Bearish" in tf.trend)
    total = max(len(inp.timeframes), 1)
    return bullish_votes / total, bearish_votes / total


def _macro_score(inp: SignalInputs):
    bullish = bearish = 0.3
    if inp.dxy_bias == "Bearish":       # weaker dollar -> supportive of gold
        bullish += 0.35
    elif inp.dxy_bias == "Bullish":
        bearish += 0.35
    if inp.yield_trend == "Falling":
        bullish += 0.35
    elif inp.yield_trend == "Rising":
        bearish += 0.35
    return min(bullish, 1.0), min(bearish, 1.0)


def _liquidity_score(inp: SignalInputs):
    bullish = bearish = 0.3
    if inp.equal_lows_nearby:   # liquidity resting below -> potential sweep then bullish reversal
        bullish += 0.4
    if inp.equal_highs_nearby:
        bearish += 0.4
    return min(bullish, 1.0), min(bearish, 1.0)


def generate_signal(inp: SignalInputs) -> SignalOutput:
    components = {
        "technical_trend": _trend_score(inp),
        "market_structure": _structure_score(inp),
        "momentum": _momentum_score(inp),
        "support_resistance": _sr_score(inp),
        "volatility": _volatility_score(inp),
        "multi_timeframe": _mtf_score(inp),
        "macro_news": _macro_score(inp),
        "liquidity_price_action": _liquidity_score(inp),
    }

    bullish_score = sum(components[k][0] * WEIGHTS[k] for k in WEIGHTS)
    bearish_score = sum(components[k][1] * WEIGHTS[k] for k in WEIGHTS)

    reasons = []
    news_risk = "Low"
    forced_wait = False

    if inp.news_high_impact_within_window:
        news_risk = "High"
        reasons.append("High-impact news event approaching — volatility risk elevated")

    if inp.typical_spread and inp.spread > inp.typical_spread * 2:
        forced_wait = True
        reasons.append("Spread unusually wide relative to normal conditions")

    bullish_votes = sum(1 for tf in inp.timeframes if "Bullish" in tf.trend)
    bearish_votes = sum(1 for tf in inp.timeframes if "Bearish" in tf.trend)
    if bullish_votes > 0 and bearish_votes > 0:
        reasons.append("Timeframes disagree — mixed multi-timeframe picture")

    diff = bullish_score - bearish_score
    total_possible = sum(WEIGHTS.values())

    if forced_wait or (inp.news_high_impact_within_window and abs(diff) < total_possible * 0.25):
        signal = "WAIT"
        if inp.news_high_impact_within_window and not forced_wait:
            reasons.append("Technical confidence insufficient to trade through news risk")
    elif diff > total_possible * 0.20:
        signal = "BUY"
        reasons.append(f"Bullish score {bullish_score:.0f} outweighs bearish score {bearish_score:.0f}")
    elif diff < -total_possible * 0.20:
        signal = "SELL"
        reasons.append(f"Bearish score {bearish_score:.0f} outweighs bullish score {bullish_score:.0f}")
    else:
        signal = "WAIT"
        reasons.append("No decisive edge between bullish and bearish factors")

    score = max(bullish_score, bearish_score)
    return SignalOutput(
        signal=signal,
        score=round(score, 1),
        bullish_score=round(bullish_score, 1),
        bearish_score=round(bearish_score, 1),
        reasons=reasons,
        news_risk=news_risk,
    )
