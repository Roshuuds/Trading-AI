import pandas as pd
from app.services.market_structure import find_swings


def psychological_levels(price: float, step: float = 50.0, span: int = 3):
    """Round-number levels within `span` steps of current price, e.g. 2300/2350/2400."""
    base = round(price / step) * step
    return [base + step * i for i in range(-span, span + 1)]


def cluster_levels(prices: list[float], tolerance: float = 2.5):
    """Group nearby swing prices into zones; more touches = stronger level."""
    if not prices:
        return []
    prices = sorted(prices)
    clusters = [[prices[0]]]
    for p in prices[1:]:
        if abs(p - clusters[-1][-1]) <= tolerance:
            clusters[-1].append(p)
        else:
            clusters.append([p])

    zones = []
    for c in clusters:
        strength = "Strong" if len(c) >= 4 else "Medium" if len(c) >= 2 else "Weak"
        zones.append({"price": round(sum(c) / len(c), 2), "touches": len(c), "strength": strength})
    return sorted(zones, key=lambda z: -z["touches"])


def compute_support_resistance(df: pd.DataFrame, current_price: float, daily_df: pd.DataFrame = None,
                                weekly_df: pd.DataFrame = None) -> dict:
    swing_highs, swing_lows = find_swings(df, lookback=3)
    resistance_zones = cluster_levels([p for _, p in swing_highs])
    support_zones = cluster_levels([p for _, p in swing_lows])

    prior_day_high = float(daily_df["high"].iloc[-2]) if daily_df is not None and len(daily_df) > 1 else None
    prior_day_low = float(daily_df["low"].iloc[-2]) if daily_df is not None and len(daily_df) > 1 else None
    prior_week_high = float(weekly_df["high"].iloc[-2]) if weekly_df is not None and len(weekly_df) > 1 else None
    prior_week_low = float(weekly_df["low"].iloc[-2]) if weekly_df is not None and len(weekly_df) > 1 else None

    return {
        "resistance": resistance_zones,
        "support": support_zones,
        "prior_day_high": prior_day_high,
        "prior_day_low": prior_day_low,
        "prior_week_high": prior_week_high,
        "prior_week_low": prior_week_low,
        "psychological_levels": psychological_levels(current_price),
    }
