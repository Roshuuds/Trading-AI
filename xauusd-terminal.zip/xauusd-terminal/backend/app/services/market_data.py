"""
Provider-agnostic market data layer. Ships with NO working live provider —
you must implement `_fetch_from_provider` for whichever data source you
connect (broker REST API, Polygon.io, Twelve Data, OANDA, etc.) using
app.config.settings.MARKET_DATA_* env vars.

Until a provider is configured, every call raises MarketDataUnavailable,
and callers must surface "Live market data unavailable." rather than
inventing a price or candle.
"""
import httpx
from app.config import settings


class MarketDataUnavailable(Exception):
    pass


async def get_current_price(symbol: str = "XAUUSD") -> dict:
    if not settings.MARKET_DATA_PROVIDER or not settings.MARKET_DATA_API_KEY:
        raise MarketDataUnavailable("No market data provider configured")

    # Example shape for a generic REST provider — replace with your provider's
    # actual endpoint/auth/response parsing.
    url = f"{settings.MARKET_DATA_BASE_URL}/quote"
    params = {"symbol": symbol, "apikey": settings.MARKET_DATA_API_KEY}
    async with httpx.AsyncClient(timeout=5.0) as client:
        try:
            resp = await client.get(url, params=params)
            resp.raise_for_status()
        except httpx.HTTPError as e:
            raise MarketDataUnavailable(str(e))
    data = resp.json()
    # Map provider fields -> our normalized schema. Adjust per provider docs.
    return {
        "symbol": symbol,
        "price": data.get("price"),
        "bid": data.get("bid"),
        "ask": data.get("ask"),
        "spread": (data.get("ask") - data.get("bid")) if data.get("ask") and data.get("bid") else None,
        "timestamp": data.get("timestamp"),
    }


async def get_candles(symbol: str = "XAUUSD", timeframe: str = "15m", limit: int = 300) -> list[dict]:
    if not settings.MARKET_DATA_PROVIDER or not settings.MARKET_DATA_API_KEY:
        raise MarketDataUnavailable("No market data provider configured")

    url = f"{settings.MARKET_DATA_BASE_URL}/candles"
    params = {"symbol": symbol, "interval": timeframe, "limit": limit,
              "apikey": settings.MARKET_DATA_API_KEY}
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            resp = await client.get(url, params=params)
            resp.raise_for_status()
        except httpx.HTTPError as e:
            raise MarketDataUnavailable(str(e))
    return resp.json().get("candles", [])


def get_trading_session(utc_hour: int) -> str:
    """Rough session boundaries in UTC. Tune to your broker's server time."""
    if 0 <= utc_hour < 7:
        return "Asian"
    if 7 <= utc_hour < 12:
        return "London"
    if 12 <= utc_hour < 16:
        return "London/New York Overlap"
    if 16 <= utc_hour < 21:
        return "New York"
    return "Asian"
