"""
Bar-by-bar backtester. Signals must be generated using only data available
up to (and including) the bar being evaluated — the caller is responsible
for ensuring the signal_fn does not peek ahead (see model_validation.py for
the walk-forward split used when an ML model drives entries).
"""
import pandas as pd
from dataclasses import dataclass, field


@dataclass
class Trade:
    entry_time: object
    direction: str      # BUY / SELL
    entry_price: float
    stop_loss: float
    take_profit: float
    exit_time: object = None
    exit_price: float = None
    result: str = "Pending"   # Win / Loss / Breakeven / Pending
    r_multiple: float = 0.0


@dataclass
class BacktestResult:
    starting_balance: float
    ending_balance: float
    trades: list = field(default_factory=list)
    win_rate: float = 0.0
    profit_factor: float = 0.0
    max_drawdown: float = 0.0
    average_win: float = 0.0
    average_loss: float = 0.0
    longest_losing_streak: int = 0
    equity_curve: list = field(default_factory=list)


def run_backtest(df: pd.DataFrame, signal_fn, starting_balance: float, risk_percent: float,
                  spread: float = 0.30, slippage: float = 0.10, contract_size_oz: float = 100.0
                  ) -> BacktestResult:
    balance = starting_balance
    equity_curve = [balance]
    trades: list[Trade] = []
    open_trade: Trade = None

    for i in range(len(df)):
        row = df.iloc[i]
        window = df.iloc[: i + 1]  # only past+current data visible to signal_fn

        if open_trade:
            hit_tp = (row["high"] >= open_trade.take_profit) if open_trade.direction == "BUY" \
                else (row["low"] <= open_trade.take_profit)
            hit_sl = (row["low"] <= open_trade.stop_loss) if open_trade.direction == "BUY" \
                else (row["high"] >= open_trade.stop_loss)

            if hit_sl or hit_tp:
                exit_price = open_trade.stop_loss if hit_sl else open_trade.take_profit
                exit_price += -slippage if open_trade.direction == "BUY" and hit_sl else 0
                risk_per_oz = abs(open_trade.entry_price - open_trade.stop_loss)
                reward_per_oz = abs(exit_price - open_trade.entry_price)
                r_multiple = (reward_per_oz / risk_per_oz) * (1 if hit_tp else -1)
                pnl = balance * (risk_percent / 100) * r_multiple

                open_trade.exit_time = row.name
                open_trade.exit_price = exit_price
                open_trade.result = "Win" if hit_tp else "Loss"
                open_trade.r_multiple = round(r_multiple, 2)
                balance += pnl
                trades.append(open_trade)
                equity_curve.append(balance)
                open_trade = None

        if not open_trade:
            sig = signal_fn(window)
            if sig and sig.get("signal") in ("BUY", "SELL"):
                entry = row["close"] + (spread / 2 if sig["signal"] == "BUY" else -spread / 2)
                open_trade = Trade(
                    entry_time=row.name,
                    direction=sig["signal"],
                    entry_price=entry,
                    stop_loss=sig["stop_loss"],
                    take_profit=sig["take_profit_1"],
                )

    wins = [t for t in trades if t.result == "Win"]
    losses = [t for t in trades if t.result == "Loss"]
    gross_profit = sum(t.r_multiple for t in wins)
    gross_loss = abs(sum(t.r_multiple for t in losses))

    # max drawdown from equity curve
    peak = equity_curve[0]
    max_dd = 0.0
    for eq in equity_curve:
        peak = max(peak, eq)
        max_dd = max(max_dd, (peak - eq) / peak if peak else 0)

    # longest losing streak
    streak = longest = 0
    for t in trades:
        if t.result == "Loss":
            streak += 1
            longest = max(longest, streak)
        else:
            streak = 0

    return BacktestResult(
        starting_balance=starting_balance,
        ending_balance=round(balance, 2),
        trades=trades,
        win_rate=round(len(wins) / len(trades) * 100, 2) if trades else 0.0,
        profit_factor=round(gross_profit / gross_loss, 2) if gross_loss else 0.0,
        max_drawdown=round(max_dd * 100, 2),
        average_win=round(sum(t.r_multiple for t in wins) / len(wins), 2) if wins else 0.0,
        average_loss=round(sum(t.r_multiple for t in losses) / len(losses), 2) if losses else 0.0,
        longest_losing_streak=longest,
        equity_curve=equity_curve,
    )
