from dataclasses import dataclass


@dataclass
class RiskCalcInput:
    account_balance: float
    risk_percent: float          # 0.25, 0.5, 1.0
    stop_loss_distance: float    # in price points (USD per oz for XAUUSD)
    contract_size_oz: float      # MUST come from the connected broker, not assumed


@dataclass
class RiskCalcOutput:
    amount_at_risk: float
    recommended_lots: float
    recommended_units_oz: float


def calculate_position_size(inp: RiskCalcInput) -> RiskCalcOutput:
    if inp.contract_size_oz <= 0 or inp.stop_loss_distance <= 0:
        raise ValueError("contract_size_oz and stop_loss_distance must be positive")

    amount_at_risk = inp.account_balance * (inp.risk_percent / 100)
    # Risk per 1 unit(oz) = stop_loss_distance (price move per oz)
    recommended_units_oz = amount_at_risk / inp.stop_loss_distance
    recommended_lots = recommended_units_oz / inp.contract_size_oz

    return RiskCalcOutput(
        amount_at_risk=round(amount_at_risk, 2),
        recommended_lots=round(recommended_lots, 4),
        recommended_units_oz=round(recommended_units_oz, 4),
    )
