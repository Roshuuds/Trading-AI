from fastapi import APIRouter
from datetime import datetime, timezone
from app.services import market_data
from app.schemas import PriceResponse

router = APIRouter(prefix="/api/xauusd", tags=["market"])


@router.get("/price", response_model=PriceResponse)
async def get_price():
    session = market_data.get_trading_session(datetime.now(timezone.utc).hour)
    try:
        data = await market_data.get_current_price("XAUUSD")
        return PriceResponse(
            symbol="XAUUSD",
            price=data["price"],
            bid=data["bid"],
            ask=data["ask"],
            spread=data["spread"],
            market_status="OPEN",
            session=session,
            data_status="live",
        )
    except market_data.MarketDataUnavailable:
        return PriceResponse(
            symbol="XAUUSD",
            market_status="UNKNOWN",
            session=session,
            data_status="unavailable",
            message="Live market data unavailable.",
        )


@router.get("/candles")
async def get_candles(timeframe: str = "15m", limit: int = 300):
    try:
        candles = await market_data.get_candles("XAUUSD", timeframe, limit)
        return {"symbol": "XAUUSD", "timeframe": timeframe, "candles": candles, "data_status": "live"}
    except market_data.MarketDataUnavailable:
        return {"symbol": "XAUUSD", "timeframe": timeframe, "candles": [],
                "data_status": "unavailable", "message": "Live market data unavailable."}
