import pandas as pd
from datetime import datetime, timezone
from fastapi import APIRouter
from app.services import market_data
from app.services.indicators import compute_all_indicators
from app.services.market_structure import analyze_market_structure
from app.services.support_resistance import compute_support_resistance
from app.services.signal_engine import generate_signal, SignalInputs, TimeframeView
from app.schemas import SignalResponse

router = APIRouter(prefix="/api/xauusd", tags=["signal"])

PRIMARY_TIMEFRAMES = ["15m", "1h", "4h"]


@router.get("/signal", response_model=SignalResponse)
async def get_signal():
    try:
        raw_candles = {tf: await market_data.get_candles("XAUUSD", tf, 300) for tf in PRIMARY_TIMEFRAMES}
    except market_data.MarketDataUnavailable:
        return SignalResponse(
            signal="WAIT",
            score=0,
            entry_zone={"low": None, "high": None},
            stop_loss=None,
            take_profit=[],
            risk_reward=None,
            trend=None,
            market_structure=None,
            momentum=None,
            news_risk="Unknown",
            reasons=["Live market data unavailable. No signal generated."],
            data_timestamp=None,
        )

    frames = {}
    for tf, candles in raw_candles.items():
        if not candles:
            return SignalResponse(
                signal="WAIT", score=0, entry_zone={"low": None, "high": None},
                stop_loss=None, take_profit=[], risk_reward=None, trend=None,
                market_structure=None, momentum=None, news_risk="Unknown",
                reasons=[f"Insufficient {tf} candle data — no signal generated."],
                data_timestamp=None,
            )
        df = pd.DataFrame(candles).set_index("timestamp")
        frames[tf] = compute_all_indicators(df)

    primary = frames["1h"]
    last = primary.iloc[-1]
    structure_info = analyze_market_structure(primary)
    sr = compute_support_resistance(primary, current_price=last["close"])

    tf_views = []
    for tf, df in frames.items():
        row = df.iloc[-1]
        trend = "Bullish" if row["close"] > row["ema_50"] else "Bearish"
        momentum = "Strong" if row["adx_14"] > 25 else "Medium" if row["adx_14"] > 15 else "Weak"
        tf_views.append(TimeframeView(timeframe=tf, trend=trend, momentum=momentum))

    nearest_support = sr["support"][0]["price"] if sr["support"] else None
    nearest_resistance = sr["resistance"][0]["price"] if sr["resistance"] else None

    inputs = SignalInputs(
        price=last["close"],
        ema_20=last["ema_20"], ema_50=last["ema_50"], ema_200=last.get("ema_200", last["ema_50"]),
        rsi_14=last["rsi_14"], macd_hist=last["macd_hist"], adx_14=last["adx_14"], atr_14=last["atr_14"],
        market_structure=structure_info["structure"],
        nearest_support=nearest_support, nearest_resistance=nearest_resistance,
        timeframes=tf_views,
        spread=0.30, typical_spread=0.30,  # replace with live spread from market_data
        news_high_impact_within_window=False,  # wire up to /news module
    )
    result = generate_signal(inputs)

    atr = last["atr_14"]
    if result.signal == "BUY":
        entry_zone = {"low": round(last["close"] - atr * 0.25, 2), "high": round(last["close"], 2)}
        stop_loss = round(last["close"] - atr * 1.5, 2)
        tp = [round(last["close"] + atr * m, 2) for m in (1.5, 2.5, 4.0)]
    elif result.signal == "SELL":
        entry_zone = {"low": round(last["close"], 2), "high": round(last["close"] + atr * 0.25, 2)}
        stop_loss = round(last["close"] + atr * 1.5, 2)
        tp = [round(last["close"] - atr * m, 2) for m in (1.5, 2.5, 4.0)]
    else:
        entry_zone, stop_loss, tp = {"low": None, "high": None}, None, []

    rr = None
    if stop_loss and tp:
        risk = abs(last["close"] - stop_loss)
        reward = abs(tp[0] - last["close"])
        rr = round(reward / risk, 2) if risk else None

    return SignalResponse(
        signal=result.signal,
        score=result.score,
        entry_zone=entry_zone,
        stop_loss=stop_loss,
        take_profit=tp,
        risk_reward=rr,
        trend=structure_info["structure"],
        market_structure=structure_info["structure"],
        momentum=tf_views[-1].momentum if tf_views else None,
        news_risk=result.news_risk,
        reasons=result.reasons,
        data_timestamp=datetime.now(timezone.utc).isoformat(),
    )
