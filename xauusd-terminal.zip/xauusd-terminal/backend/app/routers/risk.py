from fastapi import APIRouter, HTTPException
from app.schemas import RiskCalcRequest
from app.services.risk_calculator import calculate_position_size, RiskCalcInput

router = APIRouter(prefix="/api/risk", tags=["risk"])


@router.post("/calculate")
def calculate(req: RiskCalcRequest):
    if req.risk_percent not in (0.25, 0.5, 1.0):
        raise HTTPException(400, "risk_percent must be one of 0.25, 0.5, 1.0")
    try:
        result = calculate_position_size(RiskCalcInput(
            account_balance=req.account_balance,
            risk_percent=req.risk_percent,
            stop_loss_distance=req.stop_loss_distance,
            contract_size_oz=req.contract_size_oz,
        ))
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {
        "recommended_position_size_lots": result.recommended_lots,
        "recommended_position_size_oz": result.recommended_units_oz,
        "estimated_amount_at_risk": result.amount_at_risk,
    }
