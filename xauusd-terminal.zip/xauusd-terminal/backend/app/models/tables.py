from sqlalchemy import (
    Column, Integer, String, Float, Boolean, DateTime, ForeignKey, JSON, Text
)
from sqlalchemy.sql import func
from app.database import Base


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class MarketData(Base):
    """Raw OHLC candles per timeframe. Never populated with synthetic prices —
    only written to by the market_data service when a real provider is connected."""
    __tablename__ = "market_data"
    id = Column(Integer, primary_key=True)
    symbol = Column(String, default="XAUUSD", index=True)
    timeframe = Column(String, index=True)  # 1m,5m,15m,30m,1h,4h,1d
    timestamp = Column(DateTime(timezone=True), index=True)
    open = Column(Float)
    high = Column(Float)
    low = Column(Float)
    close = Column(Float)
    volume = Column(Float, nullable=True)
    bid = Column(Float, nullable=True)
    ask = Column(Float, nullable=True)
    spread = Column(Float, nullable=True)
    source = Column(String)  # which provider produced this row


class Signal(Base):
    __tablename__ = "signals"
    id = Column(Integer, primary_key=True)
    symbol = Column(String, default="XAUUSD")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    signal = Column(String)          # BUY / SELL / WAIT
    score = Column(Float)            # 0-100 signal confidence (NOT a win probability)
    entry_low = Column(Float, nullable=True)
    entry_high = Column(Float, nullable=True)
    stop_loss = Column(Float, nullable=True)
    take_profit_1 = Column(Float, nullable=True)
    take_profit_2 = Column(Float, nullable=True)
    take_profit_3 = Column(Float, nullable=True)
    risk_reward = Column(Float, nullable=True)
    trend = Column(String, nullable=True)
    market_structure = Column(String, nullable=True)
    momentum = Column(String, nullable=True)
    news_risk = Column(String, nullable=True)
    reasons = Column(JSON, nullable=True)
    features_used = Column(JSON, nullable=True)   # for auditability
    model_version = Column(String, nullable=True)
    market_price_at_signal = Column(Float, nullable=True)


class SignalResult(Base):
    """Outcome of a signal, appended only — never overwrites the original signal
    to prevent misleading backfilled performance."""
    __tablename__ = "signal_results"
    id = Column(Integer, primary_key=True)
    signal_id = Column(Integer, ForeignKey("signals.id"), index=True)
    outcome = Column(String)  # Win / Loss / Pending / Breakeven
    closed_price = Column(Float, nullable=True)
    closed_at = Column(DateTime(timezone=True), nullable=True)
    pnl_r = Column(Float, nullable=True)  # result in R-multiples


class NewsEvent(Base):
    __tablename__ = "news"
    id = Column(Integer, primary_key=True)
    event = Column(String)
    scheduled_time = Column(DateTime(timezone=True), index=True)
    impact = Column(String)  # HIGH / MEDIUM / LOW
    expected = Column(String, nullable=True)
    previous = Column(String, nullable=True)
    actual = Column(String, nullable=True)
    source = Column(String, nullable=True)


class SupportResistanceLevel(Base):
    __tablename__ = "support_resistance"
    id = Column(Integer, primary_key=True)
    symbol = Column(String, default="XAUUSD")
    level_type = Column(String)   # support / resistance
    price = Column(Float)
    strength = Column(String)     # Strong / Medium / Weak
    basis = Column(String)        # swing / prior_day / prior_week / psychological
    timeframe = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Backtest(Base):
    __tablename__ = "backtests"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    params = Column(JSON)
    starting_balance = Column(Float)
    ending_balance = Column(Float)
    win_rate = Column(Float)
    trades = Column(Integer)
    max_drawdown = Column(Float)
    profit_factor = Column(Float)
    sharpe_ratio = Column(Float, nullable=True)
    longest_losing_streak = Column(Integer, nullable=True)
    equity_curve = Column(JSON, nullable=True)


class UserAlert(Base):
    __tablename__ = "user_alerts"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    alert_type = Column(String)  # buy_signal, sell_signal, price_level, news
    config = Column(JSON)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class ModelVersion(Base):
    __tablename__ = "model_versions"
    id = Column(Integer, primary_key=True)
    version = Column(String, unique=True)
    trained_at = Column(DateTime(timezone=True))
    metrics = Column(JSON)  # accuracy, precision, recall, f1, roc_auc, sharpe, etc.
    notes = Column(Text, nullable=True)
    is_active = Column(Boolean, default=False)
