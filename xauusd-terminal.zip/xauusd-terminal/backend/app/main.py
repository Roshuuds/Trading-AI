from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

from app.config import settings
from app.routers import market, signal, risk

limiter = Limiter(key_func=get_remote_address)

app = FastAPI(title=settings.APP_NAME)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # restrict to your deployed frontend origin(s)
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

app.include_router(market.router)
app.include_router(signal.router)
app.include_router(risk.router)


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "app": settings.APP_NAME,
        "market_data_provider_configured": bool(settings.MARKET_DATA_PROVIDER),
        "news_provider_configured": bool(settings.NEWS_PROVIDER),
    }


@app.get("/")
def root():
    return {
        "message": settings.APP_NAME,
        "disclaimer": (
            "This platform provides market analysis and probability-based signals "
            "for educational and informational purposes only. It does not guarantee "
            "profits or predict future prices with certainty. Trading XAUUSD involves "
            "substantial risk, including the possibility of losing your entire trading "
            "capital. Always verify market conditions and use appropriate risk management."
        ),
    }
