from pydantic import BaseModel
from typing import Optional


class PriceResponse(BaseModel):
    symbol: str
    price: Optional[float] = None
    bid: Optional[float] = None
    ask: Optional[float] = None
    spread: Optional[float] = None
    change: Optional[float] = None
    change_percent: Optional[float] = None
    market_status: str
    session: Optional[str] = None
    data_status: str  # "live" | "unavailable" | "delayed"
    message: Optional[str] = None


class SignalResponse(BaseModel):
    symbol: str = "XAUUSD"
    signal: str
    score: float
    entry_zone: dict
    stop_loss: Optional[float]
    take_profit: list
    risk_reward: Optional[float]
    trend: Optional[str]
    market_structure: Optional[str]
    momentum: Optional[str]
    news_risk: str
    reasons: list[str]
    data_timestamp: Optional[str]
    disclaimer: str = (
        "This is a probability-based signal confidence, not a guaranteed outcome. "
        "Trading XAUUSD involves substantial risk."
    )


class RiskCalcRequest(BaseModel):
    account_balance: float
    risk_percent: float
    stop_loss_distance: float
    contract_size_oz: float


class BacktestRequest(BaseModel):
    start_date: str
    end_date: str
    timeframe: str
    risk_percent: float
    starting_balance: float = 10000.0
